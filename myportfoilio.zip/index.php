<?php 
error_reporting(0);
if(isset($_POST['submit']))
{
  
   //$to = "aishspark10@gmail.com";
	$to = "sampeen608@gmail.com";
	$from = $_POST['email']; 
    $name = $_POST['name'];
    $contactno = $_POST['contactno'];
    $email= $_POST['email'];
    $message=$_POST['message'];
   //$subject = "Enquiry Form";
    $subject2 = "Enquiry Form";
    $message ="Name:". $name ."\n\n". "Phone No:". $contactno ."\n\n". "Email:". $email ."\n\n"."Message:". $message;
   //$message2 = "Here is a copy of your message.You Sent a mail to  Ektha Developers" . "\n\n" .$message;
    $headers = "From:" . $from;
    $headers2 = "to:" . $to;
    mail($to,$subject2,$message,$headers);
    //mail($from,$subject2,$message2,$headers2);// sends a copy of the message to 
	
	?>
	<script>alert("Thank You..We will contact you soon");</script>
	<?php
   
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>responsive personal portfolio website design tutorail</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

</head>
<body>
    
<!-- header section starts  -->

<header>

    <div class="user">
        <img src="images/pic.png" alt="">
        <h3 class="name">Shama Parveen</h3>
        <p class="post">Web developer</p>
    </div>

    <nav class="navbar">
        <ul>
            <li><a href="#home">home</a></li>
            <li><a href="#about">about</a></li>
            <li><a href="#education">education</a></li>
            <!--li><a href="#portfolio">portfolio</a></li-->
            <li><a href="#contact">contact</a></li>
        </ul>
    </nav>

</header>



<div id="menu" class="fas fa-bars"></div>



<section class="home" id="home">

    <h3>HI THERE !</h3>
    <h1>I'M <span>Shama Parveen</span></h1>
    <p>Talented and experienced front-end
developer with 1+ years of experience
executing with a plethora of diverse
skills. Experience has taught me to take
accessibility and responsiveness
seriously, and I am excited to continue
my career at Web Designs with a focus
on making Web site developments easily
accessible, completely responsive, and
inherent for users.

    </p>
    <a href="#about"><button class="btn">about me <i class="fas fa-user"></i></button></a>

</section>


<section class="about" id="about">

<h1 class="heading"> <span>about</span> me </h1>

<div class="row">

    <div class="info">
        <h3> <span> name : </span> Shama Parveen </h3>
        <h3> <span> age : </span> 23 </h3>
        <h3> <span> qualification : </span> BCA </h3>
        <h3> <span> post : </span> Web developer </h3>
        <h3> <span> language : </span> Hindi,Kannnada,Tulu,English </h3>
        <a href="shama.pdf"><button class="btn"> download CV <i class="fas fa-download"></i> </button></a>
    </div>

    <div class="counter">

        <div class="box">
            <span>2+</span>
            <h3>years of experience</h3>
        </div>

        <div class="box">
            <span>40+</span>
            <h3>porject completed</h3>
        </div>

        <div class="box">
            <span>40+</span>
            <h3>happy clients</h3>
        </div>

        
    </div>

</div>

</section>



<section class="education" id="education">

<h1 class="heading"> my <span>education</span> </h1>

<div class="box-container">


    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2019</span>
        <h3>BCA</h3>
        <p>Persued Bachelor of Computer Application from St.Mary's College Shirva "Mangalore University" !</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2016</span>
        <h3>2nd PUC</h3>
        <p>Persued 2nd PUC from AL-Ihsan Women's PU College Moolur "State Board"!</p>
    </div>

    <div class="box">
        <i class="fas fa-graduation-cap"></i>
        <span>2014</span>
        <h3>SSLC</h3>
        <p>Persued metric from MET Public School Udyavara "State Board"!</p>
    </div>

</div>

</section>

<section class="contact" id="contact">

<h1 class="heading"> <span>contact</span> me </h1>

<div class="row">

    <div class="content">

        <h3 class="title">contact info</h3>

        <div class="info">
            <h3> <i class="fas fa-envelope"></i> sampeen608@gmail.com </h3>
            <h3> <i class="fas fa-phone"></i> +123-456-7890 </h3>
            <h3> <i class="fas fa-phone"></i> +111-222-3333 </h3>
            <h3> <i class="fas fa-map-marker-alt"></i> karnataka, india - 574117. </h3>
        </div>

    </div>

    <form action="index.php">

        <input type="text" name="name" placeholder="name" class="box">
        <input type="email" name="email" placeholder="email" class="box">
        <input type="number" name="contactno" placeholder="Contact No" class="box">
        <textarea name="" id="" cols="30" rows="10" class="box message" placeholder="message"></textarea>
        <button type="submit" name="submit" class="btn"> send <i class="fas fa-paper-plane"></i> </button>

    </form>

</div>

</section>


<a href="#home" class="top">
    <img src="images/scroll-top-img.png" alt="">
</a>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>


</body>
</html>